using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// HDRP-compatible Buoyancy System
/// Attach to any Rigidbody object. Assign the WaterSurface transform to match your river/ocean plane.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
[AddComponentMenu("Water/Buoyancy System")]
public class BuoyancySystem : MonoBehaviour
{
    // ─────────────────────────────────────────────
    //  CORE TOGGLE
    // ─────────────────────────────────────────────

    [Tooltip("Master switch — disables all buoyancy forces without removing the component.")]
    public bool buoyancyEnabled = true;

    // ─────────────────────────────────────────────
    //  WATER SURFACE
    // ─────────────────────────────────────────────

    [Header("Water Surface")]
    [Tooltip("Transform of your water plane. Y position is used as the water level.")]
    public Transform waterSurface;

    [Tooltip("Offset added on top of the water surface Y. Useful for wave crests.")]
    public float waterLevelOffset = 0f;

    // ─────────────────────────────────────────────
    //  BUOYANCY FORCES
    // ─────────────────────────────────────────────

    [Header("Buoyancy Forces")]

    [Tooltip("Upward force multiplier. Match to your object's mass for neutral float.")]
    [Range(0f, 200f)]
    public float buoyancyForce = 10f;

    [Tooltip("How much the object resists vertical motion in water (dampens bobbing).")]
    [Range(0f, 10f)]
    public float damping = 1.5f;

    [Tooltip("Points on the object tested for submersion. More points = smoother rotation response.")]
    public List<Transform> floatPoints = new List<Transform>();

    // ─────────────────────────────────────────────
    //  ADVANCED SYSTEMS
    // ─────────────────────────────────────────────

    [Header("Advanced")]

    // Waves
    [Tooltip("Simulate sine-wave bobbing on top of physics forces.")]
    public bool enableWaves = true;

    [Tooltip("Height of the procedural wave bob.")]
    [Range(0f, 2f)]
    public float waveHeight = 0.15f;

    [Tooltip("Speed of the procedural wave bob.")]
    [Range(0f, 5f)]
    public float waveFrequency = 1.2f;

    [Tooltip("Horizontal phase shift so nearby objects don't bob in sync.")]
    [Range(0f, 10f)]
    public float wavePhaseOffset = 0f;

    // Drag
    [Tooltip("Apply water drag while submerged (overrides Rigidbody drag when underwater).")]
    public bool enableWaterDrag = true;

    [Tooltip("Linear drag applied while any float point is submerged.")]
    [Range(0f, 10f)]
    public float waterLinearDrag = 2.5f;

    [Tooltip("Angular drag applied while any float point is submerged.")]
    [Range(0f, 10f)]
    public float waterAngularDrag = 1.5f;

    // Tilt stabilisation
    [Tooltip("Gently upright the object when tilted — simulates a keel effect.")]
    public bool enableTiltStabilisation = true;

    [Tooltip("Strength of the uprighting torque.")]
    [Range(0f, 20f)]
    public float stabilisationStrength = 5f;

    [Tooltip("Maximum tilt angle (degrees) before stabilisation activates.")]
    [Range(0f, 45f)]
    public float stabilisationDeadzone = 5f;

    // Splash FX
    [Tooltip("Spawn a particle effect when the object enters the water.")]
    public bool enableSplashFX = true;

    [Tooltip("Particle System prefab to spawn on water entry.")]
    public ParticleSystem splashPrefab;

    [Tooltip("Minimum speed (m/s) required to trigger a splash.")]
    [Range(0f, 10f)]
    public float splashSpeedThreshold = 1.5f;

    // ─────────────────────────────────────────────
    //  PRIVATE STATE
    // ─────────────────────────────────────────────

    private Rigidbody _rb;
    private float _defaultLinearDrag;
    private float _defaultAngularDrag;
    private bool _wasSubmergedLastFrame;
    private float _timeOffset;

    // ─────────────────────────────────────────────
    //  INIT
    // ─────────────────────────────────────────────

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        _defaultLinearDrag = _rb.linearDamping;
        _defaultAngularDrag = _rb.angularDamping;
        _timeOffset = Random.Range(0f, 100f); // desync multiple objects
    }

    // ─────────────────────────────────────────────
    //  PHYSICS UPDATE
    // ─────────────────────────────────────────────

    private void FixedUpdate()
    {
        if (!buoyancyEnabled) return;
        if (waterSurface == null) return;

        float waterY = waterSurface.position.y + waterLevelOffset;
        bool anySubmerged = false;
        int submergedCount = 0;

        // Wave contribution this frame
        float waveOffset = enableWaves
            ? Mathf.Sin((_timeOffset + wavePhaseOffset + Time.time) * waveFrequency) * waveHeight
            : 0f;

        float effectiveWaterY = waterY + waveOffset;

        // ── Per float-point forces ──
        if (floatPoints.Count > 0)
        {
            foreach (Transform fp in floatPoints)
            {
                if (fp == null) continue;

                float depth = effectiveWaterY - fp.position.y;

                if (depth > 0f)
                {
                    anySubmerged = true;
                    submergedCount++;

                    // Upward buoyancy proportional to submersion depth
                    float force = buoyancyForce * depth;

                    // Vertical damping
                    float verticalVel = _rb.GetPointVelocity(fp.position).y;
                    float dampForce = -verticalVel * damping;

                    _rb.AddForceAtPosition(
                        Vector3.up * (force + dampForce),
                        fp.position,
                        ForceMode.Force
                    );
                }
            }
        }
        else
        {
            // Fallback: use object centre if no float points assigned
            float depth = effectiveWaterY - transform.position.y;

            if (depth > 0f)
            {
                anySubmerged = true;
                float force = buoyancyForce * depth;
                float verticalVel = _rb.linearVelocity.y;
                float dampForce = -verticalVel * damping;
                _rb.AddForce(Vector3.up * (force + dampForce), ForceMode.Force);
            }
        }

        // ── Water drag ──
        if (enableWaterDrag)
        {
            _rb.linearDamping = anySubmerged ? waterLinearDrag : _defaultLinearDrag;
            _rb.angularDamping = anySubmerged ? waterAngularDrag : _defaultAngularDrag;
        }

        // ── Tilt stabilisation ──
        if (enableTiltStabilisation && anySubmerged)
        {
            ApplyTiltStabilisation();
        }

        // ── Splash FX ──
        if (enableSplashFX && splashPrefab != null)
        {
            bool justEntered = anySubmerged && !_wasSubmergedLastFrame;

            if (justEntered && _rb.linearVelocity.magnitude >= splashSpeedThreshold)
            {
                Vector3 spawnPos = waterSurface != null
                    ? new Vector3(transform.position.x, effectiveWaterY, transform.position.z)
                    : transform.position;

                ParticleSystem fx = Instantiate(splashPrefab, spawnPos, Quaternion.identity);
                fx.Play();
                Destroy(fx.gameObject, fx.main.duration + fx.main.startLifetime.constantMax);
            }
        }

        _wasSubmergedLastFrame = anySubmerged;
    }

    // ─────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────

    private void ApplyTiltStabilisation()
    {
        Vector3 up = transform.up;
        Vector3 world = Vector3.up;
        float angle = Vector3.Angle(up, world);

        if (angle > stabilisationDeadzone)
        {
            Vector3 torque = Vector3.Cross(up, world) * stabilisationStrength;
            _rb.AddTorque(torque, ForceMode.Force);
        }
    }

    // ─────────────────────────────────────────────
    //  GIZMOS
    // ─────────────────────────────────────────────

    private void OnDrawGizmosSelected()
    {
        float waterY = waterSurface != null
            ? waterSurface.position.y + waterLevelOffset
            : 0f;

        // Water level plane
        Gizmos.color = new Color(0.1f, 0.5f, 0.9f, 0.25f);
        Gizmos.DrawCube(
            new Vector3(transform.position.x, waterY, transform.position.z),
            new Vector3(4f, 0.02f, 4f)
        );

        // Float points
        foreach (Transform fp in floatPoints)
        {
            if (fp == null) continue;
            bool submerged = fp.position.y < waterY;
            Gizmos.color = submerged ? Color.cyan : Color.yellow;
            Gizmos.DrawSphere(fp.position, 0.08f);
        }

        // Centre fallback indicator
        if (floatPoints.Count == 0)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireSphere(transform.position, 0.15f);
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
//  CUSTOM EDITOR
// ═════════════════════════════════════════════════════════════════════════════

#if UNITY_EDITOR
[CustomEditor(typeof(BuoyancySystem))]
public class BuoyancySystemEditor : Editor
{
    // Style cache
    private GUIStyle _headerStyle;
    private GUIStyle _toggleActiveStyle;
    private GUIStyle _toggleInactiveStyle;
    private GUIStyle _sectionBoxStyle;
    private bool _stylesInitialised;

    private static readonly Color ColEnabled = new Color(0.25f, 0.75f, 0.45f);
    private static readonly Color ColDisabled = new Color(0.75f, 0.30f, 0.30f);
    private static readonly Color ColSection = new Color(0.15f, 0.18f, 0.22f, 1f);

    private void InitStyles()
    {
        if (_stylesInitialised) return;

        _headerStyle = new GUIStyle(EditorStyles.boldLabel)
        {
            fontSize = 11,
            alignment = TextAnchor.MiddleLeft
        };

        _toggleActiveStyle = new GUIStyle(GUI.skin.button)
        {
            fontStyle = FontStyle.Bold,
            fontSize = 12,
            fixedHeight = 30
        };

        _toggleInactiveStyle = new GUIStyle(_toggleActiveStyle);

        _sectionBoxStyle = new GUIStyle("helpBox")
        {
            padding = new RectOffset(10, 10, 8, 8),
            margin = new RectOffset(0, 0, 4, 4)
        };

        _stylesInitialised = true;
    }

    public override void OnInspectorGUI()
    {
        InitStyles();

        BuoyancySystem sys = (BuoyancySystem)target;
        serializedObject.Update();

        EditorGUILayout.Space(4);

        // ── Master toggle button ──────────────────────────────────────────
        Color prevBG = GUI.backgroundColor;
        GUI.backgroundColor = sys.buoyancyEnabled ? ColEnabled : ColDisabled;

        string toggleLabel = sys.buoyancyEnabled
            ? "⬆  Buoyancy  ON"
            : "✖  Buoyancy  OFF";

        if (GUILayout.Button(toggleLabel, _toggleActiveStyle))
        {
            Undo.RecordObject(sys, "Toggle Buoyancy");
            sys.buoyancyEnabled = !sys.buoyancyEnabled;
            EditorUtility.SetDirty(sys);
        }

        GUI.backgroundColor = prevBG;
        EditorGUILayout.Space(6);

        // Dim everything when disabled
        EditorGUI.BeginDisabledGroup(!sys.buoyancyEnabled);

        // ── Water Surface ────────────────────────────────────────────────
        DrawSection("Water Surface", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waterSurface"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waterLevelOffset"));
        });

        // ── Buoyancy Forces ──────────────────────────────────────────────
        DrawSection("Buoyancy Forces", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("buoyancyForce"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("damping"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("floatPoints"));
        });

        // ── Waves ────────────────────────────────────────────────────────
        DrawAdvancedSection("Waves", "enableWaves", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waveHeight"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waveFrequency"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("wavePhaseOffset"));
        });

        // ── Water Drag ───────────────────────────────────────────────────
        DrawAdvancedSection("Water Drag", "enableWaterDrag", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waterLinearDrag"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("waterAngularDrag"));
        });

        // ── Tilt Stabilisation ───────────────────────────────────────────
        DrawAdvancedSection("Tilt Stabilisation", "enableTiltStabilisation", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("stabilisationStrength"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("stabilisationDeadzone"));
        });

        // ── Splash FX ────────────────────────────────────────────────────
        DrawAdvancedSection("Splash FX", "enableSplashFX", () =>
        {
            EditorGUILayout.PropertyField(serializedObject.FindProperty("splashPrefab"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("splashSpeedThreshold"));
        });

        EditorGUI.EndDisabledGroup();

        // ── Info box when no water surface set ───────────────────────────
        if (sys.waterSurface == null && sys.buoyancyEnabled)
        {
            EditorGUILayout.Space(4);
            EditorGUILayout.HelpBox(
                "Assign a Water Surface transform — the Y position defines the water level.",
                MessageType.Warning
            );
        }

        serializedObject.ApplyModifiedProperties();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void DrawSection(string title, System.Action content)
    {
        EditorGUILayout.BeginVertical(_sectionBoxStyle);
        EditorGUILayout.LabelField(title, _headerStyle);
        EditorGUILayout.Space(2);
        content();
        EditorGUILayout.EndVertical();
    }

    private void DrawAdvancedSection(string title, string toggleProp, System.Action content)
    {
        SerializedProperty prop = serializedObject.FindProperty(toggleProp);

        EditorGUILayout.BeginVertical(_sectionBoxStyle);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField(title, _headerStyle);
        GUILayout.FlexibleSpace();

        Color prevBG = GUI.backgroundColor;
        GUI.backgroundColor = prop.boolValue ? ColEnabled : new Color(0.4f, 0.4f, 0.4f);
        string btnLabel = prop.boolValue ? "ON" : "OFF";

        if (GUILayout.Button(btnLabel, GUILayout.Width(42), GUILayout.Height(18)))
        {
            prop.boolValue = !prop.boolValue;
        }

        GUI.backgroundColor = prevBG;
        EditorGUILayout.EndHorizontal();

        if (prop.boolValue)
        {
            EditorGUILayout.Space(2);
            EditorGUI.indentLevel++;
            content();
            EditorGUI.indentLevel--;
        }

        EditorGUILayout.EndVertical();
    }
}
#endif
