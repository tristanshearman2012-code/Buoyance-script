# 🌊 Buoyancy System for Unity 6 (HDRP)

A polished, physics-based buoyancy component for Unity 6 with HDRP support. Drop it on any Rigidbody and your objects will float, bob, drag, stabilise, and splash — all controllable from a clean custom Inspector.

![Unity](https://img.shields.io/badge/Unity-6.x-black?logo=unity) ![HDRP](https://img.shields.io/badge/Pipeline-HDRP-blue) ![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

- **Master on/off toggle** — disable buoyancy instantly without removing the component
- **Multi-point float system** — assign child transforms as float points for accurate per-corner forces and natural rotation
- **Procedural waves** — sine-wave bobbing with per-object phase offset so nearby objects don't move in sync
- **Water drag** — automatically swaps Rigidbody drag values when submerged and restores them on exit
- **Tilt stabilisation** — corrective torque keeps objects upright, simulating a keel effect
- **Splash FX** — spawns a particle prefab on water entry above a configurable speed threshold
- **Scene Gizmos** — visualise the water level plane and float point submersion state in the editor
- **SRP Batcher compatible**
- **Zero dependencies** — single script, no packages required

---

## 🚀 Setup

### 1. Add the component
Select your GameObject (must have a `Rigidbody`) and add the component via:

```
Component → Water → Buoyancy System
```

Or drag `BuoyancySystem.cs` into your project and add it manually in the Inspector.

### 2. Assign a Water Surface
Create an empty GameObject (or use your water plane) and assign it to the **Water Surface** field. The Y position of this transform is used as the water level.

### 3. Add Float Points *(recommended)*
Create empty child GameObjects at the corners/edges of your object (e.g. `FL`, `FR`, `BL`, `BR` for a boat) and assign them to the **Float Points** list. More points = smoother, more realistic rotation response.

> If no float points are assigned, the object's centre pivot is used as a fallback.

### 4. Tune and play
Hit Play. Use the sliders and ON/OFF toggles in the Inspector to dial in the feel.

---

## 🔧 Inspector Reference

### Master Toggle
| Control | Description |
|---|---|
| **Buoyancy ON / OFF** | Enables or disables all buoyancy forces. Component stays attached. |

### Water Surface
| Property | Description |
|---|---|
| Water Surface | Transform whose Y position defines the water level |
| Water Level Offset | Additional Y offset on top of the surface (useful for wave crests) |

### Buoyancy Forces
| Property | Description |
|---|---|
| Buoyancy Force | Upward force multiplier — increase for heavier objects |
| Damping | Resists vertical velocity, controls how much the object bobs |
| Float Points | List of child transforms used as buoyancy sample points |

### Advanced Systems
Each advanced system has its own **ON / OFF** toggle.

| System | Key Properties |
|---|---|
| **Waves** | Wave Height, Wave Frequency, Wave Phase Offset |
| **Water Drag** | Water Linear Drag, Water Angular Drag |
| **Tilt Stabilisation** | Stabilisation Strength, Stabilisation Deadzone (degrees) |
| **Splash FX** | Splash Prefab (ParticleSystem), Splash Speed Threshold |

---

## 💡 Tips

- **Boats / crates** — place 4 float points at the bottom corners for stable, realistic rocking
- **Buoyancy Force** should roughly equal `mass × 10` for neutral floating at the surface
- **Wave Phase Offset** — randomise this per object so a fleet of boats doesn't bob in unison
- **Splash FX** — any looping particle system works; the script auto-destroys it after playback
- Gizmos are visible when the object is selected in Scene view — cyan spheres are submerged, yellow are above water

---

## 🧱 Requirements

| Requirement | Version |
|---|---|
| Unity | 6.x (tested on 6.3) |
| Render Pipeline | HDRP (any version supported by Unity 6) |
| Rigidbody | Required on the same GameObject |

> The script uses standard Unity physics and is HDRP-agnostic at runtime — the HDRP tag only affects the companion river shader. The buoyancy script itself will work in URP or Built-in with no changes.

---

## 📄 License

MIT — free to use in personal and commercial projects. See [LICENSE](LICENSE) for full terms.

---

## 🙌 Contributing

Issues and PRs welcome. If you use this in a project, a credit or a star on the repo is always appreciated but never required.